#Assignment 1 Reflection

Part 1

I hate introducing myself so this was not the funnest assignment I've ever had. However, it was nice to get know my group, so I'm glad that we did it.

I wasn't sure if we were supposed to submit a .py file or a Jupyter notebook for Part 2, but the coding itself was easy enough.
I'm looking forward to the real programming down the road. Quintin and I get along well. I don't think we will have any problems in the future.