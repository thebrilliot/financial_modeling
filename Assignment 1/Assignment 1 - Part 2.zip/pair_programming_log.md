09/14/2020, Monday, 4:25 - 4:45, Landon and Quintin, 20 mins
Driver order and time length:
Quintin, 20 minutes
Landon, 20 minutes